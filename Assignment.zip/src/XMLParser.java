import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import java.io.File;
import java.io.IOException;

/*
* Get the document builder
* Get the document
* Normalize the XML structure
* Get all the elements by the tag name
*/

public class XMLParser {

    public static void main(String[] args) {
        DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();

        try {
            DocumentBuilder builder = factory.newDocumentBuilder();

            //Get the Document
            Document document = builder.parse(new File("Employee.xml"));

            document.getDocumentElement().normalize();

            NodeList employeeList = document.getElementsByTagName("employee");

            for (int i = 0; i <employeeList.getLength(); i++){
                Node employee = employeeList.item(i);

                if (employee.getNodeType() == Node.ELEMENT_NODE){
                    Element employeeElement = (Element) employee;
                    System.out.println("Employee Id: " + employeeElement.getAttribute("id"));

                    NodeList employeeDetails = employee.getChildNodes();

                    for (int j = 0; j < employeeDetails.getLength(); j++){

                        Node detail = employeeDetails.item(j);
                        if (detail.getNodeType() == Node.ELEMENT_NODE){
                            Element detailElement = (Element) detail;
                            System.out.println("    " + detailElement.getTagName().toUpperCase() + ": " + detailElement.getTextContent());
                        }
                    }
                }
            }

        } catch (ParserConfigurationException | IOException | SAXException e) {
            throw new RuntimeException(e);
        }

    }
}
